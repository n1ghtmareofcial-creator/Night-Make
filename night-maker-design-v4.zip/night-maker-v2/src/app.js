(() => {
  const reduce = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  const finePointer = window.matchMedia('(pointer:fine)').matches;
  const $ = (s, root=document) => root.querySelector(s);
  const $$ = (s, root=document) => [...root.querySelectorAll(s)];

  // Custom cursor: one RAF loop, no layout reads during pointer movement.
  if (finePointer && !reduce) {
    const cursor = $('.cursor'), label = $('.cursor-label');
    let tx = innerWidth/2, ty = innerHeight/2, x = tx, y = ty, raf;
    addEventListener('pointermove', e => { tx=e.clientX; ty=e.clientY; label.style.left=`${tx}px`; label.style.top=`${ty}px`; }, {passive:true});
    const render = () => {
      x += (tx-x)*.18; y += (ty-y)*.18;
      cursor.style.transform = `translate3d(${x}px,${y}px,0) translate(-50%,-50%)`;
      raf = requestAnimationFrame(render);
    };
    render();
    $$('a,button,.work-card,.service-row').forEach(el => {
      el.addEventListener('pointerenter', () => { cursor.classList.add('is-hover'); label.style.opacity = el.classList.contains('work-card') ? '1' : '0'; });
      el.addEventListener('pointerleave', () => { cursor.classList.remove('is-hover'); label.style.opacity='0'; });
    });
    addEventListener('pagehide', () => cancelAnimationFrame(raf), {once:true});
  }

  // Mobile navigation.
  const menu = $('.menu-button'), nav = $('.navigation');
  menu?.addEventListener('click', () => {
    const open = nav.classList.toggle('open');
    menu.setAttribute('aria-expanded', String(open));
  });
  $$('.navigation a').forEach(a => a.addEventListener('click', () => {
    nav.classList.remove('open'); menu?.setAttribute('aria-expanded','false');
  }));

  // Mouse-following magnetic elements.
  if (finePointer && !reduce) {
    $$('.magnetic').forEach(el => {
      let bounds;
      el.addEventListener('pointerenter', () => { bounds=el.getBoundingClientRect(); });
      el.addEventListener('pointermove', e => {
        bounds ||= el.getBoundingClientRect();
        const dx=e.clientX-(bounds.left+bounds.width/2), dy=e.clientY-(bounds.top+bounds.height/2);
        el.style.transform=`translate3d(${dx*.12}px,${dy*.16}px,0)`;
      });
      el.addEventListener('pointerleave', () => { el.style.transform=''; bounds=null; });
    });
  }

  // Generative particle field: pointer repulsion + slow drift, shared engine.
  function particleField(canvas, density, radius, force, shape='field') {
    if (!canvas) return;
    const ctx=canvas.getContext('2d',{alpha:true});
    if (!ctx) return;
    let w=0,h=0,dpr=1,points=[],raf=0,visible=true;
    const pointer={x:-9999,y:-9999,down:false};
    const resize=()=>{
      const r=canvas.getBoundingClientRect(); w=r.width; h=r.height; dpr=Math.min(devicePixelRatio||1,1.5);
      canvas.width=Math.max(1,Math.round(w*dpr)); canvas.height=Math.max(1,Math.round(h*dpr)); ctx.setTransform(dpr,0,0,dpr,0,0);
      const count=Math.min(1700,Math.max(120,Math.floor(w*h/density)));
      points=Array.from({length:count},(_,i)=>{
        const a=Math.random()*Math.PI*2, rad=Math.sqrt(Math.random());
        const sx=shape==='orb' ? w/2+Math.cos(a)*Math.min(w,h)*.27*rad : Math.random()*w;
        const sy=shape==='orb' ? h/2+Math.sin(a)*Math.min(w,h)*.27*rad : Math.random()*h;
        return {x:sx,y:sy,ox:sx,oy:sy,r:Math.random()*1.2+.25,phase:Math.random()*6.28,alpha:.18+Math.random()*.75};
      });
    };
    const move=e=>{const r=canvas.getBoundingClientRect();pointer.x=e.clientX-r.left;pointer.y=e.clientY-r.top;};
    const leave=()=>{pointer.x=pointer.y=-9999;pointer.down=false;};
    canvas.addEventListener('pointermove',move,{passive:true}); canvas.addEventListener('pointerleave',leave);
    canvas.addEventListener('pointerdown',()=>pointer.down=true); canvas.addEventListener('pointerup',()=>pointer.down=false);
    const draw=t=>{
      if(!visible){raf=0;return;}
      ctx.clearRect(0,0,w,h);
      for(const p of points){
        const dx=p.ox-pointer.x,dy=p.oy-pointer.y,dist=Math.hypot(dx,dy)||1;
        const influence=Math.max(0,1-dist/radius), push=influence*force*(pointer.down?1.8:1);
        const drift=reduce?0:Math.sin(t*.00035+p.phase)*1.8;
        const px=p.ox+(dx/dist)*push,py=p.oy+(dy/dist)*push+drift;
        ctx.globalAlpha=p.alpha*(.72+Math.sin(t*.001+p.phase)*.15);
        ctx.fillStyle='#fff';ctx.fillRect(px,py,p.r,p.r);
      }
      ctx.globalAlpha=1;
      if(!reduce) raf=requestAnimationFrame(draw);
    };
    const ro=new ResizeObserver(resize);ro.observe(canvas);resize();
    const io=new IntersectionObserver(entries=>{
      visible=entries[0].isIntersecting;
      if(visible&&!raf) raf=requestAnimationFrame(draw);
      if(!visible&&raf){cancelAnimationFrame(raf);raf=0;}
    },{threshold:0});
    io.observe(canvas);
    if(!reduce) raf=requestAnimationFrame(draw); else draw(0);
    return ()=>{cancelAnimationFrame(raf);ro.disconnect();io.disconnect();canvas.removeEventListener('pointermove',move);canvas.removeEventListener('pointerleave',leave);};
  }
  particleField($('#hero-particles'),470,145,25,'field');
  particleField($('#orb-points'),95,115,18,'orb');
  particleField($('#lab-particles'),260,210,54,'field');

  // ScrollTrigger: cinematic entrances, pinned narrative moments and progress.
  if (window.gsap && window.ScrollTrigger && !reduce) {
    gsap.registerPlugin(ScrollTrigger);
    gsap.config({nullTargetWarn:false});
    gsap.from('.hero-kicker',{y:18,opacity:0,duration:1,delay:.25,ease:'power3.out'});
    gsap.from('.title-line',{yPercent:115,opacity:0,duration:1.35,stagger:.14,ease:'power4.out',delay:.2});
    gsap.from('.orb-stage',{scale:.72,opacity:0,duration:1.6,ease:'power3.out',delay:.35});
    // The artwork is now a persistent visual layer. It travels through the page
    // on a deliberately organic path instead of snapping between sections.
    const signalPath = gsap.timeline({
      defaults:{ease:'sine.inOut'},
      scrollTrigger:{trigger:document.body,start:'top top',end:'bottom bottom',scrub:2.6}
    });
    signalPath
      .to('.hero-image-scene',{xPercent:-34,yPercent:-43,scale:.88,duration:1})
      .to('.hero-image-scene',{xPercent:30,yPercent:-35,scale:1.04,rotate:1.2,duration:1})
      .to('.hero-image-scene',{xPercent:40,yPercent:18,scale:.76,rotate:-1.5,duration:1})
      .to('.hero-image-scene',{xPercent:-42,yPercent:28,scale:.96,rotate:.8,duration:1})
      .to('.hero-image-scene',{xPercent:-28,yPercent:-18,scale:.82,rotate:-1.1,duration:1})
      .to('.hero-image-scene',{xPercent:38,yPercent:-10,scale:1.02,rotate:1.3,duration:1})
      .to('.hero-image-scene',{xPercent:24,yPercent:34,scale:.79,rotate:-.7,duration:1})
      .to('.hero-image-scene',{xPercent:-36,yPercent:20,scale:.93,rotate:1,duration:1})
      .to('.hero-image-scene',{xPercent:0,yPercent:-28,scale:1.08,rotate:-.4,duration:1});

    gsap.to('.orb-stage',{yPercent:22,scale:.86,rotate:12,ease:'none',scrollTrigger:{trigger:'.hero',start:'top top',end:'bottom top',scrub:2}});
    gsap.to('.hero-title',{yPercent:-18,opacity:.25,ease:'none',scrollTrigger:{trigger:'.hero',start:'top top',end:'bottom top',scrub:2.2}});
    gsap.to('.scroll-progress span',{height:'100%',ease:'none',scrollTrigger:{trigger:document.body,start:'top top',end:'bottom bottom',scrub:1.1}});

    $$('.reveal-up').forEach(el=>gsap.from(el,{y:55,opacity:0,duration:1.15,ease:'expo.out',scrollTrigger:{trigger:el,start:'top 88%',scrub:0.25}}));
    $$('.reveal-line > span').forEach(el=>gsap.from(el,{yPercent:115,duration:1.15,ease:'power4.out',scrollTrigger:{trigger:el.closest('.intro-title'),start:'top 78%',toggleActions:'play none none reverse'}}));
    gsap.from('.manifesto-title',{y:120,opacity:0,duration:1.35,ease:'expo.out',scrollTrigger:{trigger:'.manifesto',start:'top 65%',scrub:0.35}});
    gsap.to('.manifesto-watermark',{yPercent:-18,ease:'none',scrollTrigger:{trigger:'.manifesto',start:'top bottom',end:'bottom top',scrub:1}});
    gsap.from('.work-card',{y:90,opacity:0,stagger:.18,duration:1.05,ease:'expo.out',scrollTrigger:{trigger:'.work-grid',start:'top 80%',scrub:0.3}});
    $$('.work-visual').forEach(el=>gsap.fromTo(el,{clipPath:'inset(12% 8% 12% 8%)'},{clipPath:'inset(0% 0% 0% 0%)',duration:1.1,ease:'power3.out',scrollTrigger:{trigger:el,start:'top 85%'}}));
    gsap.from('.showcase-copy h2',{y:100,opacity:0,duration:1.1,scrollTrigger:{trigger:'.showcase',start:'top 65%'}});
    gsap.from('.browser-frame',{y:100,rotateY:-18,opacity:0,duration:1.2,ease:'power3.out',scrollTrigger:{trigger:'.browser-scene',start:'top 80%'}});
    gsap.from('.service-row',{x:-55,opacity:0,stagger:.12,duration:.9,ease:'expo.out',scrollTrigger:{trigger:'.service-list',start:'top 82%',scrub:0.25}});
    gsap.from('.experiment-stage',{scale:.94,opacity:0,duration:1.25,ease:'expo.out',scrollTrigger:{trigger:'.experiment-stage',start:'top 82%',scrub:0.3}});
    gsap.from('.tech-layout > *',{y:65,opacity:0,stagger:.18,duration:1.1,ease:'expo.out',scrollTrigger:{trigger:'.tech-layout',start:'top 78%',scrub:0.3}});
    gsap.to('.process-progress',{width:'100%',ease:'none',scrollTrigger:{trigger:'.process-track',start:'top 75%',end:'bottom 65%',scrub:.5}});
    $$('.process-track article').forEach((el,i)=>ScrollTrigger.create({trigger:el,start:'top 72%',onEnter:()=>el.classList.add('is-active'),onLeaveBack:()=>el.classList.remove('is-active')}));
    gsap.from('.contact h2',{y:110,opacity:0,duration:1.35,ease:'expo.out',scrollTrigger:{trigger:'.contact',start:'top 70%',scrub:0.35}});
    ScrollTrigger.refresh();
  } else {
    document.documentElement.classList.add('reduced-motion');
  }

  // Coordinate readout in the generative playground.
  const lab=$('#lab-particles'), coordX=$('#coord-x'), coordY=$('#coord-y');
  lab?.addEventListener('pointermove',e=>{
    const r=lab.getBoundingClientRect();
    coordX.textContent=String(Math.round(e.clientX-r.left)).padStart(3,'0');
    coordY.textContent=String(Math.round(e.clientY-r.top)).padStart(3,'0');
  },{passive:true});
})();