# NIGHT MAKER — Design prototype v2

A versão 02 concentra-se exclusivamente na direção visual e nas interações de mouse e scroll.

## Executar
Abra `index.html` em um navegador moderno. Para melhor compatibilidade, use um servidor estático local (por exemplo, Live Server).

## Interações incluídas
- Cursor personalizado com estado de hover.
- Botões e links magnéticos.
- Campos de partículas reativos ao ponteiro.
- Partículas com resposta ao clique no playground.
- Animações de entrada e saída com GSAP + ScrollTrigger.
- Parallax no hero e no manifesto.
- Indicador de progresso de rolagem.
- Revelação de títulos por linhas.
- Animações de composição dos projetos.
- Progresso animado da linha de processo.
- Menu adaptado para dispositivos móveis.

## Dependências externas
GSAP e ScrollTrigger são carregados por CDN. As fontes Manrope e DM Mono são carregadas pelo Google Fonts.

## Escopo desta versão
O painel administrativo, upload/publicação de ZIP, autenticação e backend foram intencionalmente deixados de fora. Esta etapa é dedicada ao design e à experiência de mouse/scroll, como solicitado.


## Visual update
The supplied `sinal.webp` artwork is used as the persistent hero/background visual. Its position, scale and rotation travel organically through the page with a long, softened GSAP ScrollTrigger scrub.
